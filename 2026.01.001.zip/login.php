<?php
session_start();

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

function json_read(string $file, $fallback) {
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    $data = json_decode($raw, true);

    return (json_last_error() === JSON_ERROR_NONE) ? $data : $fallback;
}

$error = '';
$email = '';
$theme = 'default';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailInput = trim($_POST['email'] ?? '');
    $emailValid = filter_var($emailInput, FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    $email = $emailInput;

    if (!$emailValid) {
        $error = "Email invalide.";
    } else {
        $email = $emailValid;

        $userDir     = __DIR__ . '/users/profiles/' . $email . '/';
        $profilePath = $userDir . 'profile.json';
        $themePath   = $userDir . 'theme.json';

        if (is_file($themePath)) {
            $themeData = json_read($themePath, []);

            if (
                !empty($themeData['theme']) &&
                is_file(__DIR__ . '/theme/' . basename($themeData['theme']) . '/style.css')
            ) {
                $theme = basename($themeData['theme']);
            }
        }

        if (is_file($profilePath)) {
            $profile = json_read($profilePath, []);

            if (
                is_array($profile) &&
                isset($profile['motdepasse']) &&
                password_verify($password, $profile['motdepasse'])
            ) {
                $_SESSION['user'] = [
                    'email'        => $profile['email'] ?? $email,
                    'prenom'       => $profile['prenom'] ?? '',
                    'nom'          => $profile['nom'] ?? '',
                    'role_system'  => $profile['role_system'] ?? '',
                    'role_metier'  => $profile['role_metier'] ?? ''
                ];

                $_SESSION['role_system'] = $profile['role_system'] ?? 'user';

                header('Location: dashboard.php');
                exit;
            }

            $error = "Mot de passe incorrect.";
        } else {
            $error = "Utilisateur non trouvé.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Se connecter</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
</head>

<body>

<main class="login-wrapper">
    <section class="login-card" aria-labelledby="login-title">

        <div class="brand">
            <img src="adm/uploads/logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
            <h1 id="login-title">Se connecter</h1>
        </div>

        <p class="subtitle">
            Votre espace de travail modulaire, privé et élégant.
        </p>

        <?php if (!empty($error)): ?>
            <div class="error-message">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="post" action="" autocomplete="on" novalidate>
            <label for="email">Adresse e-mail</label>
            <input
                type="email"
                id="email"
                name="email"
                placeholder="vous@exemple.com"
                value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="password">Mot de passe</label>
            <input
                type="password"
                id="password"
                name="password"
                placeholder="••••••••"
                required
            >

            <button type="submit" class="btn">
                Se connecter
            </button>

            <a class="register-link" href="register.php">
                Créer un compte
            </a>

            <p class="footnote">
                Accès réservé • <strong>DoMyDesk</strong> — Modular Private Workspace
            </p>
        </form>

    </section>
</main>

</body>
</html>