<?php
session_start();

if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

$viewerEmail = $_SESSION['user']['email'];
$viewerRole  = $_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? 'user');

$viewerDir = __DIR__ . '/users/profiles/' . $viewerEmail . '/';
$themeJson = $viewerDir . 'theme.json';
$theme     = 'default';

if (file_exists($themeJson)) {
    $themeData = json_decode(file_get_contents($themeJson), true);

    if (
        !empty($themeData['theme']) &&
        file_exists(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
}

$targetEmail = isset($_GET['user']) ? urldecode($_GET['user']) : $viewerEmail;

if (
    strpos($targetEmail, '..') !== false ||
    strpos($targetEmail, '/') !== false ||
    strpos($targetEmail, '\\') !== false
) {
    die('Paramètre utilisateur invalide.');
}

$targetDir   = __DIR__ . '/users/profiles/' . $targetEmail . '/';
$profilePath = $targetDir . 'profile.json';
$avatarPath  = $targetDir . 'avatar.png';
$modulesPath = $targetDir . 'modules.json';

if (!file_exists($profilePath)) {
    die('Profil introuvable.');
}

$profile = json_decode(file_get_contents($profilePath), true);
$modules = file_exists($modulesPath) ? json_decode(file_get_contents($modulesPath), true) : [];

if (!is_array($profile)) {
    die('Profil invalide.');
}

if (!is_array($modules)) {
    $modules = [];
}

$canEdit = (
    $targetEmail === $viewerEmail ||
    in_array($viewerRole, ['admin', 'superadmin'], true)
);

$profileTitle = trim(($profile['prenom'] ?? '') . ' ' . ($profile['nom'] ?? ''));
if ($profileTitle === '') {
    $profileTitle = $profile['email'] ?? $targetEmail;
}

$enabledModules = array_filter($modules, function ($m) {
    return is_array($m) && !empty($m['enabled']);
});
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Profil de <?= htmlspecialchars($profileTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS du thème choisi par l'utilisateur -->
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
</head>

<body>

<?php include 'header.php'; ?>

<div class="profile-scope">
    <h1>Fiche utilisateur</h1>

    <div class="section">
        <div class="profile-container">
            <div class="avatar-container">
                <?php if (file_exists($avatarPath)): ?>
                    <img
                        src="users/profiles/<?= rawurlencode($targetEmail) ?>/avatar.png?t=<?= time() ?>"
                        alt="Avatar"
                        class="avatar"
                    >
                <?php else: ?>
                    <div class="avatar fallback">
                        N/A
                    </div>
                <?php endif; ?>

                <?php if ($canEdit): ?>
                    <a
                        href="profile_edit.php?email=<?= urlencode($targetEmail) ?>"
                        class="edit-icon"
                        title="Modifier le profil"
                    >
                        ✏️ Modifier
                    </a>
                <?php endif; ?>
            </div>

            <div class="info">
                <p>
                    <strong>Prénom :</strong>
                    <?= htmlspecialchars($profile['prenom'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                </p>

                <p>
                    <strong>Nom :</strong>
                    <?= htmlspecialchars($profile['nom'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                </p>

                <p>
                    <strong>Email :</strong>
                    <?= htmlspecialchars($profile['email'] ?? $targetEmail, ENT_QUOTES, 'UTF-8') ?>
                </p>

                <p>
                    <strong>Rôle système :</strong>
                    <?= htmlspecialchars($profile['role_system'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                </p>

                <p>
                    <strong>Rôle métier :</strong>
                    <?= htmlspecialchars($profile['role_metier'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                </p>
            </div>
        </div>

        <div class="modules">
            <h2>Modules activés :</h2>

            <?php if (!empty($enabledModules)): ?>
                <ul>
                    <?php foreach ($enabledModules as $module): ?>
                        <li>
                            <?= htmlspecialchars($module['name'] ?? $module['id'] ?? 'Module', ENT_QUOTES, 'UTF-8') ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Aucun module activé.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="back-links">
        <a class="back-link" href="dashboard.php">
            ← Retour au dashboard
        </a>

        <a class="back-link" href="members.php">
            ← Retour à la liste des membres
        </a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const scope = document.querySelector('.profile-scope');
    const section = scope?.querySelector('.section');

    if (!scope || !section) {
        return;
    }

    const cs = getComputedStyle(section);
    const accent = cs.borderTopColor || cs.borderColor;

    if (accent) {
        scope.style.setProperty('--accent', accent);
    }
});
</script>

</body>
</html>