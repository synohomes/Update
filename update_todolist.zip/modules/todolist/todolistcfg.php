<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo '<div class="dmdtodo-alert dmdtodo-alert-error">Utilisateur non connecté.</div>'; return; }
function dmdtodo_safe_email($email) { return preg_replace('/[^a-zA-Z0-9@._\-]/', '_', (string)$email); }
function dmdtodo_defaults() { return ['version'=>41,'settings'=>['show_archives'=>false,'categories'=>['Perso','Pro','Courses','Maison','Administratif'],'statuses'=>['todo'=>'À faire','in_progress'=>'En cours','waiting'=>'En attente','done'=>'Terminé','archived'=>'Archivé'],'priorities'=>['low'=>'Basse','normal'=>'Normale','high'=>'Haute','urgent'=>'Urgente'],'shared_defaults'=>[]],'tasks'=>[]]; }
function dmdtodo_file($email) { $safe=dmdtodo_safe_email($email); $profile=__DIR__.'/../../users/profiles/'.$safe; if(!is_dir($profile)) @mkdir($profile,0775,true); $dir=$profile.'/todolist'; if(!is_dir($dir)) @mkdir($dir,0775,true); $new=$dir.'/todolist.json'; $old=$profile.'/todolist.json'; if(!file_exists($new)&&file_exists($old)) @rename($old,$new); return $new; }
function dmdtodo_load($email) { $file=dmdtodo_file($email); if(!file_exists($file)) file_put_contents($file,json_encode(dmdtodo_defaults(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX); $data=json_decode((string)file_get_contents($file),true); if(!is_array($data)) $data=dmdtodo_defaults(); $def=dmdtodo_defaults(); $data['settings']=array_replace_recursive($def['settings'],$data['settings']??[]); if(isset($data['categories'])&&is_array($data['categories'])){$data['settings']['categories']=$data['categories']; unset($data['categories']);} $data['tasks']=isset($data['tasks'])&&is_array($data['tasks'])?$data['tasks']:[]; return [$data,$file]; }
function dmdtodo_lines($txt){ $out=[]; foreach(preg_split('/\R+/',(string)$txt) as $v){$v=trim($v); if($v!==''&&!in_array($v,$out,true))$out[]=$v;} return $out; }
[$data,$file]=dmdtodo_load($email); $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $cats=dmdtodo_lines($_POST['categories']??''); if(!$cats) $cats=dmdtodo_defaults()['settings']['categories'];
    $data['settings']['categories']=$cats;
    $data['settings']['show_archives']=!empty($_POST['show_archives']);
    file_put_contents($file,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
    $msg='Configuration enregistrée.';
}
$cats=$data['settings']['categories'];
?>
<link rel="stylesheet" href="modules/todolist/todolist.css?v=41">
<div class="dmdtodo">
    <?php if($msg): ?><div class="dmdtodo-alert dmdtodo-alert-ok"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <form method="post" class="dmdtodo-form" style="max-width:760px">
        <div class="dmdtodo-field dmdtodo-full"><span>Catégories</span><textarea class="dmdtodo-input" name="categories" rows="8"><?= htmlspecialchars(implode("\n", $cats)) ?></textarea><small>Une catégorie par ligne. Elles sont enregistrées dans users/profiles/EMAIL/todolist/todolist.json.</small></div>
        <label class="dmdtodo-check-row"><input type="checkbox" name="show_archives" value="1" <?= !empty($data['settings']['show_archives'])?'checked':'' ?>><span>Afficher les tâches archivées</span></label>
        <div class="dmdtodo-form-actions"><button class="dmdtodo-btn dmdtodo-btn-primary" type="submit">Enregistrer</button></div>
    </form>
</div>
