<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo '<div class="dmdtodo-alert dmdtodo-alert-error">Utilisateur non connecté.</div>'; return; }

function dmdtodo_safe_email($email) { return preg_replace('/[^a-zA-Z0-9@._\-]/', '_', (string)$email); }
function dmdtodo_defaults() {
    return [
        'version'=>42,
        'settings'=>[
            'show_archives'=>false,
            'categories'=>['Perso','Pro','Courses','Maison','Administratif'],
            'statuses'=>['todo'=>'À faire','in_progress'=>'En cours','waiting'=>'En attente','done'=>'Terminé','archived'=>'Archivé'],
            'priorities'=>['low'=>'Basse','normal'=>'Normale','high'=>'Haute','urgent'=>'Urgente'],
            'shared_defaults'=>[]
        ],
        'tasks'=>[]
    ];
}
function dmdtodo_file($email) {
    $safe = dmdtodo_safe_email($email);
    $profile = __DIR__ . '/../../users/profiles/' . $safe;
    if (!is_dir($profile)) @mkdir($profile, 0775, true);
    $dir = $profile . '/todolist';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $new = $dir . '/todolist.json';
    $old = $profile . '/todolist.json';
    if (!file_exists($new) && file_exists($old)) @rename($old, $new);
    return $new;
}
function dmdtodo_load($email) {
    $file = dmdtodo_file($email);
    if (!file_exists($file)) file_put_contents($file, json_encode(dmdtodo_defaults(), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    $data = json_decode((string)file_get_contents($file), true);
    if (!is_array($data)) $data = dmdtodo_defaults();
    $def = dmdtodo_defaults();
    $data['version'] = 42;
    $data['settings'] = array_replace_recursive($def['settings'], $data['settings'] ?? []);
    if (isset($data['categories']) && is_array($data['categories'])) { $data['settings']['categories'] = $data['categories']; unset($data['categories']); }
    if (isset($data['shared_defaults']) && is_array($data['shared_defaults'])) { $data['settings']['shared_defaults'] = $data['shared_defaults']; unset($data['shared_defaults']); }
    $data['tasks'] = isset($data['tasks']) && is_array($data['tasks']) ? array_values($data['tasks']) : [];
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    return [$data, $file];
}
function dmdtodo_member_name_from_file($file) {
    $raw = @json_decode((string)@file_get_contents($file), true);
    if (!is_array($raw)) return '';
    $prenom = trim((string)($raw['prenom'] ?? $raw['first_name'] ?? $raw['firstname'] ?? ''));
    $nom = trim((string)($raw['nom'] ?? $raw['last_name'] ?? $raw['lastname'] ?? ''));
    $name = trim((string)($raw['name'] ?? $raw['display_name'] ?? ''));
    return trim($prenom . ' ' . $nom) ?: $name;
}
function dmdtodo_members($currentEmail) {
    $root = realpath(__DIR__ . '/../../users/profiles');
    $members = [];
    if ($root && is_dir($root)) {
        foreach (glob($root . '/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $mail = basename($dir);
            if ($mail === dmdtodo_safe_email($currentEmail)) continue;
            $name = '';
            foreach (['profile.json','user.json','infos.json','settings.json','account.json'] as $f) {
                if (file_exists($dir . '/' . $f)) { $name = dmdtodo_member_name_from_file($dir . '/' . $f); if ($name !== '') break; }
            }
            $members[] = ['email'=>$mail,'name'=>$name ?: $mail];
        }
    }
    usort($members, fn($a,$b)=>strcasecmp($a['name'],$b['name']));
    return $members;
}
function dmdtodo_norm_task($t) {
    $t = is_array($t) ? $t : [];
    $t['id'] = (string)($t['id'] ?? ('task_' . bin2hex(random_bytes(5))));
    $t['shared_group_id'] = (string)($t['shared_group_id'] ?? '');
    $t['title'] = trim((string)($t['title'] ?? 'Sans titre'));
    $t['description'] = (string)($t['description'] ?? '');
    $t['comment'] = (string)($t['comment'] ?? '');
    $t['category'] = (string)($t['category'] ?? '');
    $t['status'] = (string)($t['status'] ?? 'todo');
    $t['priority'] = (string)($t['priority'] ?? 'normal');
    $t['due_date'] = (string)($t['due_date'] ?? '');
    $t['shared_with'] = isset($t['shared_with']) && is_array($t['shared_with']) ? array_values($t['shared_with']) : [];
    $t['tags'] = isset($t['tags']) && is_array($t['tags']) ? array_values($t['tags']) : [];
    $t['checklist'] = isset($t['checklist']) && is_array($t['checklist']) ? array_values(array_map(function($c){
        return ['id'=>(string)($c['id'] ?? ('chk_' . bin2hex(random_bytes(4)))),'text'=>(string)($c['text'] ?? ''),'done'=>!empty($c['done']),'done_by'=>(string)($c['done_by'] ?? ''),'done_at'=>(string)($c['done_at'] ?? '')];
    }, $t['checklist'])) : [];
    $t['owner_email'] = (string)($t['owner_email'] ?? $t['created_by'] ?? '');
    $t['last_changed_by'] = (string)($t['last_changed_by'] ?? '');
    $t['updated_at'] = (string)($t['updated_at'] ?? '');
    return $t;
}
[$data] = dmdtodo_load($email);
$settings = $data['settings'];
$tasks = array_map('dmdtodo_norm_task', $data['tasks']);
$members = dmdtodo_members($email);
$today = date('Y-m-d');
usort($tasks, function($a,$b) {
    $w = ['urgent'=>4,'high'=>3,'normal'=>2,'low'=>1];
    if (($a['status']==='done') !== ($b['status']==='done')) return $a['status']==='done' ? 1 : -1;
    $pa = $w[$a['priority']] ?? 0; $pb = $w[$b['priority']] ?? 0;
    if ($pa !== $pb) return $pb <=> $pa;
    return strcmp($a['due_date'] ?: '9999-12-31', $b['due_date'] ?: '9999-12-31');
});
$visible = array_values(array_filter($tasks, fn($t)=>($t['status'] !== 'archived' || !empty($settings['show_archives']))));
$openCount = count(array_filter($visible, fn($t)=>!in_array($t['status'], ['done','archived'], true)));
$cssHref = 'modules/todolist/todolist.css?v=42';
$apiHref = 'modules/todolist/save.php';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($cssHref) ?>">
<div class="dmdtodo" data-api="<?= htmlspecialchars($apiHref) ?>">
    <div class="dmdtodo-topbar">
        
        <div class="dmdtodo-actions">
            <input class="dmdtodo-input dmdtodo-search" type="search" placeholder="Rechercher…" data-search>
            <select class="dmdtodo-input dmdtodo-cat-filter" data-cat-filter><option value="">Toutes</option><?php foreach ($settings['categories'] as $cat): ?><option><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select>
            <button type="button" class="dmdtodo-btn dmdtodo-btn-primary" data-new>+ Tâche</button>
            <button type="button" class="dmdtodo-btn" data-refresh title="Recharger les tâches synchronisées">↻</button>
            <button type="button" class="dmdtodo-btn" onclick="window.print()">PDF</button>
        </div>
    </div>
    <div class="dmdtodo-grid" data-list>
        <?php foreach ($visible as $task):
            $done = 0; $total = count($task['checklist']); foreach ($task['checklist'] as $c) if (!empty($c['done'])) $done++;
            $isLate = $task['due_date'] && $task['due_date'] < $today && !in_array($task['status'], ['done','archived'], true);
            $json = htmlspecialchars(json_encode($task, JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP), ENT_QUOTES, 'UTF-8');
        ?>
        <article class="dmdtodo-task <?= $task['status']==='done'?'is-done':'' ?> <?= $task['status']==='archived'?'is-archived':'' ?>" data-task='<?= $json ?>' data-id="<?= htmlspecialchars($task['id']) ?>" data-search="<?= htmlspecialchars(mb_strtolower($task['title'].' '.$task['description'].' '.$task['comment'].' '.$task['category'].' '.implode(' ', $task['tags']))) ?>" data-category="<?= htmlspecialchars($task['category']) ?>">
            <button type="button" class="dmdtodo-checkbtn" data-quick-status title="Terminer / rouvrir"><?= $task['status']==='done' ? '✓' : '' ?></button>
            <div class="dmdtodo-task-main">
                <div class="dmdtodo-task-title"><?= htmlspecialchars($task['title']) ?></div>
                <div class="dmdtodo-task-meta">
                    <span class="dmdtodo-chip"><?= htmlspecialchars($settings['statuses'][$task['status']] ?? $task['status']) ?></span>
                    <span class="dmdtodo-chip dmdtodo-priority-<?= htmlspecialchars($task['priority']) ?>"><?= htmlspecialchars($settings['priorities'][$task['priority']] ?? $task['priority']) ?></span>
                    <?php if ($task['category']): ?><span class="dmdtodo-chip"><?= htmlspecialchars($task['category']) ?></span><?php endif; ?>
                    <?php foreach ($task['tags'] as $tag): ?><span class="dmdtodo-chip dmdtodo-tag">#<?= htmlspecialchars($tag) ?></span><?php endforeach; ?>
                    <?php if ($task['due_date']): ?><span class="dmdtodo-chip <?= $isLate?'dmdtodo-late':'' ?>">🗓 <?= htmlspecialchars(date('d/m', strtotime($task['due_date']))) ?></span><?php endif; ?>
                    <?php if ($total): ?><span class="dmdtodo-chip">☑ <?= (int)$done ?>/<?= (int)$total ?></span><?php endif; ?>
                    <?php if (!empty($task['shared_group_id'])): ?><button type="button" class="dmdtodo-chip dmdtodo-share-chip" data-share title="Voir le partage">👥 <?= count($task['shared_with']) ?></button><?php endif; ?>
                </div>
            </div>
            <button type="button" class="dmdtodo-deletebtn" data-delete title="Supprimer">×</button>
        </article>
        <?php endforeach; ?>
    </div>
    <?php if (!$visible): ?><div class="dmdtodo-empty">Aucune tâche pour le moment.</div><?php endif; ?>
</div>

<div class="dmdtodo-modal" data-modal="view" aria-hidden="true"><section class="dmdtodo-window dmdtodo-view-window"><header class="dmdtodo-window-head"><h3 data-view-title></h3><button class="dmdtodo-close" data-close>×</button></header><div class="dmdtodo-view-body"><div class="dmdtodo-view-meta" data-view-meta></div><div class="dmdtodo-view-section" data-desc-wrap><strong>Description</strong><p data-view-desc></p></div><div class="dmdtodo-view-section" data-check-wrap><strong>Checklist</strong><div class="dmdtodo-checklist-view" data-view-checklist></div></div><div class="dmdtodo-view-section" data-comment-wrap><strong>Commentaire</strong><p data-view-comment></p></div><div class="dmdtodo-view-actions"><button class="dmdtodo-btn dmdtodo-btn-primary" data-edit>Modifier</button><button class="dmdtodo-btn" data-status="done">Terminer</button><button class="dmdtodo-btn" data-status="todo">À faire</button><button class="dmdtodo-btn dmdtodo-danger" data-delete-current>Supprimer</button><button class="dmdtodo-btn" data-close>Fermer</button></div></div></section></div>

<div class="dmdtodo-modal" data-modal="form" aria-hidden="true"><section class="dmdtodo-window dmdtodo-form-window"><header class="dmdtodo-window-head"><h3 data-form-title>Nouvelle tâche</h3><button class="dmdtodo-close" data-close>×</button></header><form class="dmdtodo-form" data-form><input type="hidden" name="id"><div class="dmdtodo-field dmdtodo-full"><span>Titre *</span><input class="dmdtodo-input" name="title" required></div><div class="dmdtodo-grid2"><label class="dmdtodo-field"><span>Catégorie</span><select class="dmdtodo-input" name="category"><?php foreach ($settings['categories'] as $cat): ?><option><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></label><label class="dmdtodo-field"><span>Priorité</span><select class="dmdtodo-input" name="priority"><?php foreach ($settings['priorities'] as $k=>$v): ?><option value="<?= htmlspecialchars($k) ?>"><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label><label class="dmdtodo-field"><span>Échéance</span><input class="dmdtodo-input" type="date" name="due_date"></label><label class="dmdtodo-field"><span>Statut</span><select class="dmdtodo-input" name="status"><?php foreach ($settings['statuses'] as $k=>$v): ?><option value="<?= htmlspecialchars($k) ?>"><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label></div><label class="dmdtodo-field dmdtodo-full"><span>Description</span><textarea class="dmdtodo-input" name="description" rows="3"></textarea></label><div class="dmdtodo-field dmdtodo-full"><span>Checklist</span><div class="dmdtodo-check-editor" data-check-editor></div><button class="dmdtodo-mini-btn" type="button" data-add-step>+ étape</button></div><details class="dmdtodo-details dmdtodo-full"><summary>Options</summary><div class="dmdtodo-grid2"><label class="dmdtodo-field"><span>Tags</span><input class="dmdtodo-input" name="tags" placeholder="client, urgent"></label><label class="dmdtodo-field"><span>Commentaire</span><input class="dmdtodo-input" name="comment"></label></div><div class="dmdtodo-field"><span>Partager / synchroniser avec</span><div class="dmdtodo-members" data-members><?php foreach ($members as $m): ?><label class="dmdtodo-member"><input type="checkbox" name="shared_with[]" value="<?= htmlspecialchars($m['email']) ?>"><span><?= htmlspecialchars($m['name']) ?></span><small><?= htmlspecialchars($m['email']) ?></small></label><?php endforeach; ?></div></div></details><div class="dmdtodo-form-actions"><button class="dmdtodo-btn dmdtodo-btn-primary" type="submit">Enregistrer</button><button class="dmdtodo-btn" type="button" data-close>Annuler</button></div></form></section></div>

<div class="dmdtodo-modal" data-modal="share" aria-hidden="true"><section class="dmdtodo-window dmdtodo-share-window"><header class="dmdtodo-window-head"><h3>Partage synchronisé</h3><button class="dmdtodo-close" data-close>×</button></header><div class="dmdtodo-view-body" data-share-body></div></section></div>

<script>
(() => {
const allTodoRoots = Array.from(document.querySelectorAll('.dmdtodo'));
const wrap = allTodoRoots[allTodoRoots.length - 1];
if (!wrap || wrap.dataset.ready) return; wrap.dataset.ready = '1';
const api = wrap.dataset.api;
const labels = {statuses: <?= json_encode($settings['statuses'], JSON_UNESCAPED_UNICODE) ?>, priorities: <?= json_encode($settings['priorities'], JSON_UNESCAPED_UNICODE) ?>};
const members = <?= json_encode($members, JSON_UNESCAPED_UNICODE) ?>;
let tasks = Array.from(wrap.querySelectorAll('[data-task]')).map(el => JSON.parse(el.dataset.task));
let current = null;
const modals = Object.fromEntries(Array.from(document.querySelectorAll('.dmdtodo-modal[data-modal]')).map(m => [m.dataset.modal, m]));
Object.values(modals).forEach(m => { if (m.parentElement !== document.body) document.body.appendChild(m); makeDrag(m.querySelector('.dmdtodo-window')); });
function esc(s){return String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));}
function fmtDate(d){if(!d)return''; const x=new Date(d+'T00:00:00'); return isNaN(x)?d:x.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'});}
function openModal(name){const m=modals[name], w=m.querySelector('.dmdtodo-window'); m.setAttribute('aria-hidden','false'); if(!w.dataset.placed){ const r=wrap.getBoundingClientRect(); w.style.left=(window.scrollX+r.left+Math.min(280, Math.max(20, r.width*.25)))+'px'; w.style.top=(window.scrollY+r.top+40)+'px'; w.dataset.placed='1'; }}
function closeModal(m){(m.closest?m.closest('.dmdtodo-modal'):m).setAttribute('aria-hidden','true');}
function chip(t){return `<span class="dmdtodo-chip">${esc(t)}</span>`;}
function checkCount(t){let total=(t.checklist||[]).length, done=(t.checklist||[]).filter(c=>c.done).length; return [done,total];}
function renderView(t){ current=t; modals.view.querySelector('[data-view-title]').textContent=t.title; let [done,total]=checkCount(t); modals.view.querySelector('[data-view-meta]').innerHTML = [labels.statuses[t.status]||t.status, labels.priorities[t.priority]||t.priority, t.category, ...(t.tags||[]).map(x=>'#'+x), t.due_date?'🗓 '+fmtDate(t.due_date):'', total?'☑ '+done+'/'+total:'', t.shared_group_id?'👥 partagé sync':''].filter(Boolean).map(chip).join(''); modals.view.querySelector('[data-view-desc]').textContent=t.description||'—'; modals.view.querySelector('[data-view-comment]').textContent=t.comment||'—'; modals.view.querySelector('[data-view-checklist]').innerHTML = total ? (t.checklist||[]).map((c,i)=>`<label class="dmdtodo-check-row"><input type="checkbox" data-check-toggle data-check-id="${esc(c.id||i)}" ${c.done?'checked':''}><span class="${c.done?'is-checked':''}">${esc(c.text)}</span>${c.done_by?`<small>${esc(c.done_by)}</small>`:''}</label>`).join('') : '<div class="dmdtodo-empty-small">Pas d’étape.</div>'; openModal('view');}
function renderShare(t){ let owner=t.owner_email||t.created_by||''; let body=`<div class="dmdtodo-view-section"><strong>Principe</strong><p>Cette tâche est synchronisée : checklist, statut et modifications sont mis à jour chez tout le monde.</p></div>`; if(owner) body+=`<div class="dmdtodo-view-section"><strong>Créée par</strong><p>${esc(owner)}</p></div>`; body+=`<div class="dmdtodo-view-section"><strong>Partagée avec</strong>`; const list=t.shared_with||[]; body+= list.length ? list.map(mail=>{let m=members.find(x=>x.email===mail); return `<p>👤 <b>${esc(m?.name||mail)}</b><br><small>${esc(mail)}</small></p>`}).join('') : '<p>Personne.</p>'; body+='</div>'; if(t.last_changed_by) body+=`<div class="dmdtodo-view-section"><strong>Dernière modification</strong><p>${esc(t.last_changed_by)}</p></div>`; modals.share.querySelector('[data-share-body]').innerHTML=body; openModal('share');}
async function send(payload){const r=await fetch(api,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const j=await r.json().catch(()=>({status:'error',message:'Réponse invalide'})); if(!r.ok||j.status!=='ok') throw new Error(j.message||'Erreur'); return j;}
function replaceLocal(task){ const i=tasks.findIndex(t=>t.id===task.id || (task.shared_group_id && t.shared_group_id===task.shared_group_id)); if(i>=0) tasks[i]=task; else tasks.unshift(task); }
function reloadSoon(){ setTimeout(()=>location.reload(), 250); }
function taskFromCard(el){ return JSON.parse(el.closest('[data-task]').dataset.task); }
wrap.addEventListener('click', async e=>{
 const card=e.target.closest('[data-task]');
 if(e.target.closest('[data-share]')){e.stopPropagation(); renderShare(taskFromCard(e.target)); return;}
 if(e.target.closest('[data-delete]')){e.stopPropagation(); const t=taskFromCard(e.target); if(confirm('Supprimer cette tâche synchronisée chez tout le monde ?')){await send({action:'delete',id:t.id}); reloadSoon();} return;}
 if(e.target.closest('[data-quick-status]')){e.stopPropagation(); const t=taskFromCard(e.target); await send({action:'status',id:t.id,status:t.status==='done'?'todo':'done'}); reloadSoon(); return;}
 if(card) renderView(taskFromCard(card));
});
wrap.querySelector('[data-new]')?.addEventListener('click',()=>openForm(null));
wrap.querySelector('[data-refresh]')?.addEventListener('click',()=>location.reload());
wrap.querySelector('[data-search]')?.addEventListener('input',filter); wrap.querySelector('[data-cat-filter]')?.addEventListener('change',filter);
function filter(){const q=(wrap.querySelector('[data-search]').value||'').toLowerCase(), c=wrap.querySelector('[data-cat-filter]').value; wrap.querySelectorAll('[data-task]').forEach(el=>{el.style.display=((!q||el.dataset.search.includes(q))&&(!c||el.dataset.category===c))?'':'none';});}
document.addEventListener('click', async e=>{
 if(e.target.matches('[data-close]')) closeModal(e.target);
 if(e.target.matches('[data-edit]') && current) openForm(current);
 if(e.target.matches('[data-delete-current]') && current && confirm('Supprimer cette tâche synchronisée chez tout le monde ?')){await send({action:'delete',id:current.id}); reloadSoon();}
 if(e.target.matches('[data-status]') && current){const j=await send({action:'status',id:current.id,status:e.target.dataset.status}); current=j.task; renderView(current); reloadSoon();}
 if(e.target.matches('[data-check-toggle]') && current){e.stopPropagation(); const j=await send({action:'checklist_toggle',id:current.id,check_id:e.target.dataset.checkId,done:e.target.checked}); current=j.task; replaceLocal(current); renderView(current);}
});
function addStep(text='',done=false,id=''){ const box=modals.form.querySelector('[data-check-editor]'); const row=document.createElement('div'); row.className='dmdtodo-check-edit-row'; row.innerHTML=`<input type="checkbox" ${done?'checked':''}><input class="dmdtodo-input" value="${esc(text)}" data-check-id="${esc(id)}" placeholder="Étape"><button type="button" class="dmdtodo-mini-btn">×</button>`; row.querySelector('button').onclick=()=>row.remove(); box.appendChild(row); }
function openForm(t){ current=t; const f=modals.form.querySelector('[data-form]'); f.reset(); modals.form.querySelector('[data-form-title]').textContent=t?'Modifier la tâche':'Nouvelle tâche'; f.id.value=t?.id||''; f.title.value=t?.title||''; f.category.value=t?.category||f.category.value; f.priority.value=t?.priority||'normal'; f.due_date.value=t?.due_date||''; f.status.value=t?.status||'todo'; f.description.value=t?.description||''; f.tags.value=(t?.tags||[]).join(', '); f.comment.value=t?.comment||''; modals.form.querySelector('[data-check-editor]').innerHTML=''; (t?.checklist||[]).forEach(c=>addStep(c.text,c.done,c.id)); if(!t) addStep(); f.querySelectorAll('[name="shared_with[]"]').forEach(cb=>cb.checked=(t?.shared_with||[]).includes(cb.value)); openModal('form');}
modals.form.querySelector('[data-add-step]').onclick=()=>addStep();
modals.form.querySelector('[data-form]').addEventListener('submit', async e=>{e.preventDefault(); const f=e.currentTarget; const payload={action:f.id.value?'update':'create', id:f.id.value||undefined, title:f.title.value, category:f.category.value, priority:f.priority.value, due_date:f.due_date.value, status:f.status.value, description:f.description.value, comment:f.comment.value, tags:f.tags.value.split(',').map(x=>x.trim()).filter(Boolean), shared_with:Array.from(f.querySelectorAll('[name="shared_with[]"]:checked')).map(x=>x.value), checklist:Array.from(f.querySelectorAll('.dmdtodo-check-edit-row')).map(r=>({id:r.querySelector('input[type="text"],input[data-check-id]')?.dataset.checkId||'', text:r.querySelector('input[data-check-id]').value, done:r.querySelector('input[type="checkbox"]').checked})).filter(x=>x.text.trim())}; const j=await send(payload); replaceLocal(j.task); closeModal(modals.form); reloadSoon();});
function makeDrag(w){ if(!w) return; const h=w.querySelector('.dmdtodo-window-head'); let sx,sy,l,t,drag=false; h.addEventListener('mousedown',e=>{ if(e.target.closest('button,input,select,textarea')) return; drag=true; sx=e.clientX; sy=e.clientY; const r=w.getBoundingClientRect(); l=window.scrollX+r.left; t=window.scrollY+r.top; document.body.style.userSelect='none';}); document.addEventListener('mousemove',e=>{if(!drag)return; w.style.left=(l+e.clientX-sx)+'px'; w.style.top=(t+e.clientY-sy)+'px';}); document.addEventListener('mouseup',()=>{drag=false; document.body.style.userSelect='';}); }
})();
</script>
