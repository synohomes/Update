<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('X-Content-Type-Options: nosniff');

$email = $_SESSION['user']['email'] ?? '';
if (!$email) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'error','message'=>'Non connecté'], JSON_UNESCAPED_UNICODE);
    exit;
}

function dmdtodo_safe_email($email) { return preg_replace('/[^a-zA-Z0-9@._\-]/', '_', (string)$email); }
function dmdtodo_profiles_root() { return realpath(__DIR__ . '/../../users/profiles') ?: (__DIR__ . '/../../users/profiles'); }
function dmdtodo_defaults() {
    return [
        'version' => 41,
        'settings' => [
            'show_archives' => false,
            'categories' => ['Perso','Pro','Courses','Maison','Administratif'],
            'statuses' => ['todo'=>'À faire','in_progress'=>'En cours','waiting'=>'En attente','done'=>'Terminé','archived'=>'Archivé'],
            'priorities' => ['low'=>'Basse','normal'=>'Normale','high'=>'Haute','urgent'=>'Urgente'],
            'shared_defaults' => []
        ],
        'tasks' => []
    ];
}
function dmdtodo_user_dir($email) {
    $dir = __DIR__ . '/../../users/profiles/' . dmdtodo_safe_email($email) . '/todolist';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    return $dir;
}
function dmdtodo_file($email) {
    $safe = dmdtodo_safe_email($email);
    $profile = __DIR__ . '/../../users/profiles/' . $safe;
    if (!is_dir($profile)) @mkdir($profile, 0775, true);
    $dir = $profile . '/todolist';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $new = $dir . '/todolist.json';
    $old = $profile . '/todolist.json';
    if (!file_exists($new) && file_exists($old)) @rename($old, $new);
    return $new;
}
function dmdtodo_load($email) {
    $file = dmdtodo_file($email);
    if (!file_exists($file)) file_put_contents($file, json_encode(dmdtodo_defaults(), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    $data = json_decode((string)file_get_contents($file), true);
    if (!is_array($data)) $data = dmdtodo_defaults();
    $def = dmdtodo_defaults();
    $data['version'] = 41;
    $data['settings'] = array_replace_recursive($def['settings'], $data['settings'] ?? []);
    if (isset($data['categories']) && is_array($data['categories'])) { $data['settings']['categories'] = $data['categories']; unset($data['categories']); }
    if (isset($data['shared_defaults']) && is_array($data['shared_defaults'])) { $data['settings']['shared_defaults'] = $data['shared_defaults']; unset($data['shared_defaults']); }
    $data['tasks'] = isset($data['tasks']) && is_array($data['tasks']) ? array_values($data['tasks']) : [];
    return [$data, $file];
}
function dmdtodo_save($file, $data) { file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX); }
function dmdtodo_clean_list($arr) {
    if (!is_array($arr)) $arr = explode(',', (string)$arr);
    $out = [];
    foreach ($arr as $v) {
        $v = trim((string)$v);
        if ($v !== '' && !in_array($v, $out, true)) $out[] = $v;
    }
    return array_slice($out, 0, 80);
}
function dmdtodo_clean_emails($arr) {
    $out = [];
    foreach (dmdtodo_clean_list($arr) as $mail) {
        if (filter_var($mail, FILTER_VALIDATE_EMAIL) && !in_array($mail, $out, true)) $out[] = $mail;
    }
    return $out;
}
function dmdtodo_build_task($input, $old = [], $actorEmail = '') {
    $now = date('c');
    $title = trim((string)($input['title'] ?? $old['title'] ?? ''));
    if ($title === '') throw new Exception('Titre requis');

    $checklist = [];
    foreach (($input['checklist'] ?? $old['checklist'] ?? []) as $item) {
        if (!is_array($item)) continue;
        $txt = trim((string)($item['text'] ?? ''));
        if ($txt === '') continue;
        $checklist[] = [
            'id' => (string)($item['id'] ?? ('chk_' . bin2hex(random_bytes(5)))),
            'text' => mb_substr($txt, 0, 220),
            'done' => !empty($item['done']),
            'done_by' => !empty($item['done']) ? (string)($item['done_by'] ?? $old['done_by'] ?? $actorEmail) : '',
            'done_at' => !empty($item['done']) ? (string)($item['done_at'] ?? $now) : ''
        ];
    }

    $owner = (string)($old['owner_email'] ?? $old['created_by'] ?? $actorEmail);
    $sharedWith = dmdtodo_clean_emails($input['shared_with'] ?? $old['shared_with'] ?? []);
    $sharedWith = array_values(array_filter($sharedWith, fn($m) => dmdtodo_safe_email($m) !== dmdtodo_safe_email($owner)));
    $group = (string)($old['shared_group_id'] ?? $input['shared_group_id'] ?? '');
    if ($group === '' && !empty($sharedWith)) $group = 'grp_' . bin2hex(random_bytes(10));

    return [
        'id' => (string)($old['id'] ?? $input['id'] ?? ('task_' . bin2hex(random_bytes(8)))),
        'shared_group_id' => $group,
        'owner_email' => $owner,
        'created_by' => (string)($old['created_by'] ?? $actorEmail),
        'last_changed_by' => $actorEmail,
        'title' => mb_substr($title, 0, 180),
        'description' => mb_substr((string)($input['description'] ?? $old['description'] ?? ''), 0, 5000),
        'comment' => mb_substr((string)($input['comment'] ?? $old['comment'] ?? ''), 0, 5000),
        'category' => mb_substr(trim((string)($input['category'] ?? $old['category'] ?? '')), 0, 80),
        'status' => in_array(($input['status'] ?? $old['status'] ?? 'todo'), ['todo','in_progress','waiting','done','archived'], true) ? ($input['status'] ?? $old['status'] ?? 'todo') : 'todo',
        'priority' => in_array(($input['priority'] ?? $old['priority'] ?? 'normal'), ['low','normal','high','urgent'], true) ? ($input['priority'] ?? $old['priority'] ?? 'normal') : 'normal',
        'due_date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($input['due_date'] ?? '')) ? (string)$input['due_date'] : (string)($old['due_date'] ?? ''),
        'shared_with' => $sharedWith,
        'tags' => dmdtodo_clean_list($input['tags'] ?? $old['tags'] ?? []),
        'checklist' => $checklist,
        'created_at' => (string)($old['created_at'] ?? $now),
        'updated_at' => $now,
        'completed_at' => (($input['status'] ?? $old['status'] ?? '') === 'done') ? (string)($old['completed_at'] ?? $now) : ''
    ];
}
function dmdtodo_participants($task) {
    $p = [];
    if (!empty($task['owner_email'])) $p[] = (string)$task['owner_email'];
    foreach (($task['shared_with'] ?? []) as $m) $p[] = (string)$m;
    return array_values(array_unique(array_filter($p)));
}
function dmdtodo_sync_shared_task($task) {
    $group = (string)($task['shared_group_id'] ?? '');
    if ($group === '') return;
    $participants = dmdtodo_participants($task);
    $participantsSafe = array_map('dmdtodo_safe_email', $participants);
    $root = dmdtodo_profiles_root();
    if (!is_dir($root)) return;

    // Met à jour ou supprime les copies qui ne sont plus dans le partage.
    foreach (glob($root . '/*/todolist/todolist.json') ?: [] as $file) {
        $profileSafe = basename(dirname(dirname($file)));
        [$data] = dmdtodo_load($profileSafe);
        $changed = false;
        foreach ($data['tasks'] as $i => $t) {
            if (($t['shared_group_id'] ?? '') !== $group) continue;
            if (!in_array($profileSafe, $participantsSafe, true)) {
                unset($data['tasks'][$i]);
            } else {
                $copy = $task;
                $copy['id'] = (string)($t['id'] ?? $task['id']);
                $data['tasks'][$i] = $copy;
            }
            $changed = true;
        }
        if ($changed) { $data['tasks'] = array_values($data['tasks']); dmdtodo_save($file, $data); }
    }

    // Crée la tâche chez les participants qui ne l'ont pas encore.
    foreach ($participants as $mail) {
        [$data, $file] = dmdtodo_load($mail);
        $exists = false;
        foreach ($data['tasks'] as $t) if (($t['shared_group_id'] ?? '') === $group) { $exists = true; break; }
        if (!$exists) { $copy = $task; $copy['id'] = $task['id']; $data['tasks'][] = $copy; dmdtodo_save($file, $data); }
    }
}
function dmdtodo_delete_group($group, $fallbackId = '') {
    $root = dmdtodo_profiles_root();
    foreach (glob($root . '/*/todolist/todolist.json') ?: [] as $file) {
        $raw = json_decode((string)file_get_contents($file), true);
        if (!is_array($raw) || empty($raw['tasks'])) continue;
        $before = count($raw['tasks']);
        $raw['tasks'] = array_values(array_filter($raw['tasks'], function($t) use ($group, $fallbackId) {
            if ($group !== '' && (($t['shared_group_id'] ?? '') === $group)) return false;
            if ($group === '' && $fallbackId !== '' && (($t['id'] ?? '') === $fallbackId)) return false;
            return true;
        }));
        if (count($raw['tasks']) !== $before) dmdtodo_save($file, $raw);
    }
}
function dmdtodo_find_task(&$data, $id) {
    foreach ($data['tasks'] as $i => $t) if (($t['id'] ?? '') === $id) return $i;
    return -1;
}

try {
    header('Content-Type: application/json; charset=utf-8');
    $input = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($input)) throw new Exception('Requête invalide');
    $action = (string)($input['action'] ?? 'create');
    [$data, $file] = dmdtodo_load($email);

    if ($action === 'create') {
        $task = dmdtodo_build_task($input, [], $email);
        $data['tasks'][] = $task;
        dmdtodo_save($file, $data);
        dmdtodo_sync_shared_task($task);
        echo json_encode(['status'=>'ok','task'=>$task], JSON_UNESCAPED_UNICODE); exit;
    }

    $id = (string)($input['id'] ?? '');
    if ($id === '') throw new Exception('ID manquant');
    $idx = dmdtodo_find_task($data, $id);
    if ($idx < 0) throw new Exception('Tâche introuvable');
    $old = $data['tasks'][$idx];

    if ($action === 'delete') {
        $group = (string)($old['shared_group_id'] ?? '');
        dmdtodo_delete_group($group, $id);
        echo json_encode(['status'=>'ok','deleted'=>true,'shared_group_id'=>$group], JSON_UNESCAPED_UNICODE); exit;
    }

    if ($action === 'checklist_toggle') {
        $checkId = (string)($input['check_id'] ?? '');
        foreach ($old['checklist'] as $k => $c) {
            if ((string)($c['id'] ?? $k) === $checkId || (string)$k === $checkId) {
                $done = !empty($input['done']);
                $old['checklist'][$k]['done'] = $done;
                $old['checklist'][$k]['done_by'] = $done ? $email : '';
                $old['checklist'][$k]['done_at'] = $done ? date('c') : '';
                break;
            }
        }
        $task = dmdtodo_build_task($old, $old, $email);
    } elseif ($action === 'status') {
        $old['status'] = (string)($input['status'] ?? $old['status']);
        $task = dmdtodo_build_task($old, $old, $email);
    } elseif ($action === 'update') {
        $task = dmdtodo_build_task($input, $old, $email);
    } else {
        throw new Exception('Action inconnue');
    }

    $data['tasks'][$idx] = $task;
    dmdtodo_save($file, $data);
    dmdtodo_sync_shared_task($task);
    echo json_encode(['status'=>'ok','task'=>$task,'synced'=>!empty($task['shared_group_id'])], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'error','message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
