<?php
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function contact_json_error(string $msg, array $extra = [], int $code = 500): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg] + $extra, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function contact_json_ok(array $data = []): void {
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function contact_clean_email_path(string $email): string {
    return $email;
}

function contact_base_paths(): array {
    $email = $_SESSION['user']['email'] ?? '';
    if ($email === '') contact_json_error('AUTH', [], 403);
    $base = realpath(__DIR__ . '/../..');
    if ($base === false) contact_json_error('BASE_NOT_FOUND');
    $dir = $base . '/users/profiles/' . contact_clean_email_path($email) . '/contact';
    return [$email, $dir, $dir . '/avatars', $dir . '/contacts.json'];
}

function contact_ensure_storage(string $dir, string $avatarDir, string $dataFile): void {
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) contact_json_error('MKDIR_CONTACT', ['dir' => $dir]);
    if (!is_dir($avatarDir) && !@mkdir($avatarDir, 0775, true)) contact_json_error('MKDIR_AVATARS', ['dir' => $avatarDir]);
    if (!file_exists($dataFile) && @file_put_contents($dataFile, "[]", LOCK_EX) === false) contact_json_error('CREATE_JSON', ['file' => $dataFile]);
}

function contact_read_all(string $file): array {
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return [];
    $arr = json_decode($raw, true);
    return is_array($arr) ? $arr : [];
}

function contact_write_all(string $file, array $contacts): void {
    $contacts = array_values($contacts);
    $json = json_encode($contacts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) contact_json_error('JSON_ENCODE', ['detail' => json_last_error_msg()]);
    $tmp = $file . '.tmp';
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) contact_json_error('WRITE_TMP');
    if (!@rename($tmp, $file)) {
        $fp = @fopen($file, 'wb');
        if (!$fp) contact_json_error('OPEN_JSON');
        @flock($fp, LOCK_EX);
        $ok = @fwrite($fp, $json) !== false;
        @fflush($fp);
        @flock($fp, LOCK_UN);
        @fclose($fp);
        @unlink($tmp);
        if (!$ok) contact_json_error('WRITE_JSON');
    }
    @chmod($file, 0664);
}

function contact_post(string $key, string $default = ''): string {
    return trim((string)($_POST[$key] ?? $default));
}

function contact_bool_post(string $key): bool {
    return isset($_POST[$key]) && in_array((string)$_POST[$key], ['1', 'true', 'on', 'yes'], true);
}

function contact_upload_avatar(string $avatarDir): string {
    if (!isset($_FILES['avatar']) || !is_array($_FILES['avatar'])) return '';
    if (($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($_FILES['avatar']['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) contact_json_error('UPLOAD_ERROR', ['code' => $_FILES['avatar']['error']]);
    if (!is_uploaded_file($_FILES['avatar']['tmp_name'])) contact_json_error('UPLOAD_TMP_INVALID');
    $max = 4 * 1024 * 1024;
    if (($_FILES['avatar']['size'] ?? 0) > $max) contact_json_error('UPLOAD_TOO_LARGE');
    $info = @getimagesize($_FILES['avatar']['tmp_name']);
    if ($info === false) contact_json_error('UPLOAD_NOT_IMAGE');
    $mime = $info['mime'] ?? '';
    $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
    $ext = $map[$mime] ?? 'png';
    $name = uniqid('av_', true) . '.' . $ext;
    if (!@move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarDir . '/' . $name)) contact_json_error('UPLOAD_MOVE');
    @chmod($avatarDir . '/' . $name, 0664);
    return $name;
}

[$email, $dir, $avatarDir, $dataFile] = contact_base_paths();
contact_ensure_storage($dir, $avatarDir, $dataFile);
$contacts = contact_read_all($dataFile);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') contact_json_error('METHOD', [], 405);
$action = contact_post('action');

if ($action === 'delete' || isset($_POST['delete_contact_id'])) {
    $id = contact_post('id', contact_post('delete_contact_id'));
    if ($id === '') contact_json_error('ID_REQUIRED', [], 400);
    $deleted = false;
    foreach ($contacts as $i => $c) {
        if (($c['id'] ?? '') === $id) {
            if (!empty($c['avatar']) && is_file($avatarDir . '/' . $c['avatar'])) @unlink($avatarDir . '/' . $c['avatar']);
            unset($contacts[$i]);
            $deleted = true;
            break;
        }
    }
    contact_write_all($dataFile, $contacts);
    contact_json_ok(['deleted' => $deleted]);
}

if ($action === 'save' || ($_POST['form_contactcfg'] ?? '') === '1' || isset($_POST['prenom'])) {
    $id = contact_post('id');
    if ($id === '') $id = uniqid('c_', true);

    $isPrivate = contact_bool_post('is_private');
    $isPro = contact_bool_post('is_pro');
    if (!$isPrivate && !$isPro) $isPrivate = true;

    $newAvatar = contact_upload_avatar($avatarDir);
    $now = date('Y-m-d H:i:s');

    $record = [
        'id' => $id,
        'civilite' => contact_post('civilite'),
        'prenom' => contact_post('prenom'),
        'nom' => contact_post('nom'),
        'surnom' => contact_post('surnom'),
        'is_private' => $isPrivate,
        'is_pro' => $isPro,
        'relation_private' => contact_post('relation_private'),
        'relation_pro' => contact_post('relation_pro'),
        'entreprise' => contact_post('entreprise'),
        'poste' => contact_post('poste'),
        'service' => contact_post('service'),
        'siret' => contact_post('siret'),
        'mail' => contact_post('mail'),
        'mail2' => contact_post('mail2'),
        'tel' => contact_post('tel'),
        'tel2' => contact_post('tel2'),
        'adresse' => contact_post('adresse'),
        'code_postal' => contact_post('code_postal'),
        'ville' => contact_post('ville'),
        'pays' => contact_post('pays'),
        'date_naissance' => contact_post('date_naissance'),
        'statut_familial' => contact_post('statut_familial'),
        'site_web' => contact_post('site_web'),
        'linkedin' => contact_post('linkedin'),
        'tags' => contact_post('tags'),
        'notes' => contact_post('notes'),
        'updated_at' => $now,
    ];

    $found = false;
    foreach ($contacts as &$c) {
        if (($c['id'] ?? '') === $id) {
            $record['created_at'] = $c['created_at'] ?? $now;
            $record['avatar'] = $newAvatar ?: ($c['avatar'] ?? '');
            if ($newAvatar && !empty($c['avatar']) && is_file($avatarDir . '/' . $c['avatar'])) @unlink($avatarDir . '/' . $c['avatar']);
            $c = $record;
            $found = true;
            break;
        }
    }
    unset($c);

    if (!$found) {
        $record['created_at'] = $now;
        $record['avatar'] = $newAvatar;
        $contacts[] = $record;
    }

    usort($contacts, function ($a, $b) {
        $aa = mb_strtolower(trim(($a['nom'] ?? '') . ' ' . ($a['prenom'] ?? '')), 'UTF-8');
        $bb = mb_strtolower(trim(($b['nom'] ?? '') . ' ' . ($b['prenom'] ?? '')), 'UTF-8');
        return strcoll($aa, $bb);
    });

    contact_write_all($dataFile, $contacts);
    contact_json_ok(['id' => $id, 'count' => count($contacts)]);
}

contact_json_error('NO_ROUTE', [], 400);
