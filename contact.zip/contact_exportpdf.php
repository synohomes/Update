<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { http_response_code(403); exit('Accès refusé'); }

$base = realpath(__DIR__ . '/../..');
if ($base === false) exit('Base introuvable');
$file = $base . "/users/profiles/$email/contact/contacts.json";
if (!file_exists($file)) exit('Aucun contact à exporter.');
$contacts = json_decode((string)@file_get_contents($file), true);
if (!is_array($contacts)) $contacts = [];

$id = trim((string)($_GET['id'] ?? ''));
if ($id !== '') {
    $contacts = array_values(array_filter($contacts, fn($c) => is_array($c) && (($c['id'] ?? '') === $id)));
}

function pdf_text(string $text): string {
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    $text = iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text) ?: $text;
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
}

function contact_label_value(array $c, string $key): string {
    $v = $c[$key] ?? '';
    if (is_bool($v)) return $v ? 'Oui' : 'Non';
    if ($key === 'is_private' || $key === 'is_pro') return !empty($v) ? 'Oui' : 'Non';
    return trim((string)$v);
}

$fields = [
    'civilite' => 'Civilité', 'prenom' => 'Prénom', 'nom' => 'Nom', 'surnom' => 'Surnom',
    'is_private' => 'Privé', 'is_pro' => 'Pro', 'relation_private' => 'Type privé', 'relation_pro' => 'Type pro',
    'entreprise' => 'Entreprise', 'poste' => 'Poste', 'service' => 'Service', 'siret' => 'SIRET',
    'mail' => 'Email principal', 'mail2' => 'Email secondaire', 'tel' => 'Téléphone', 'tel2' => 'Téléphone 2',
    'adresse' => 'Adresse', 'code_postal' => 'Code postal', 'ville' => 'Ville', 'pays' => 'Pays',
    'date_naissance' => 'Date de naissance', 'statut_familial' => 'Situation familiale',
    'site_web' => 'Site web', 'linkedin' => 'LinkedIn', 'tags' => 'Tags', 'notes' => 'Notes',
    'created_at' => 'Créé le', 'updated_at' => 'Modifié le'
];

$lines = [];
$lines[] = 'Export contacts DoMyDesk';
$lines[] = 'Généré le ' . date('d/m/Y H:i');
$lines[] = '';
if (empty($contacts)) $lines[] = 'Aucun contact trouvé.';
foreach ($contacts as $index => $c) {
    if (!is_array($c)) continue;
    $title = trim(($c['prenom'] ?? '') . ' ' . ($c['nom'] ?? ''));
    if ($title === '') $title = (string)($c['entreprise'] ?? 'Contact');
    $lines[] = '----------------------------------------';
    $lines[] = strtoupper($title);
    $lines[] = '----------------------------------------';
    foreach ($fields as $key => $label) {
        $value = contact_label_value($c, $key);
        if ($value === '') $value = '—';
        $wrapped = wordwrap($label . ' : ' . $value, 92, "\n  ", true);
        foreach (explode("\n", $wrapped) as $l) $lines[] = $l;
    }
    $lines[] = '';
}

$objects = [];
$content = "BT\n/F1 11 Tf\n50 800 Td\n14 TL\n";
$y = 800;
$pageContents = [];
foreach ($lines as $line) {
    if ($y < 55) {
        $content .= "ET";
        $pageContents[] = $content;
        $content = "BT\n/F1 11 Tf\n50 800 Td\n14 TL\n";
        $y = 800;
    }
    $content .= '(' . pdf_text($line) . ") Tj\nT*\n";
    $y -= 14;
}
$content .= "ET";
$pageContents[] = $content;

$nPages = count($pageContents);
$catalogId = 1;
$pagesId = 2;
$fontId = 3;
$nextId = 4;
$pageIds = [];
$contentIds = [];
foreach ($pageContents as $pc) {
    $pageIds[] = $nextId++;
    $contentIds[] = $nextId++;
}

$pdfObjects = [];
$pdfObjects[$catalogId] = "<< /Type /Catalog /Pages $pagesId 0 R >>";
$pdfObjects[$pagesId] = "<< /Type /Pages /Kids [" . implode(' ', array_map(fn($id) => "$id 0 R", $pageIds)) . "] /Count $nPages >>";
$pdfObjects[$fontId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
foreach ($pageContents as $i => $pc) {
    $pdfObjects[$pageIds[$i]] = "<< /Type /Page /Parent $pagesId 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 $fontId 0 R >> >> /Contents {$contentIds[$i]} 0 R >>";
    $pdfObjects[$contentIds[$i]] = "<< /Length " . strlen($pc) . " >>\nstream\n$pc\nendstream";
}
ksort($pdfObjects);

$pdf = "%PDF-1.4\n";
$offsets = [0];
foreach ($pdfObjects as $id => $obj) {
    $offsets[$id] = strlen($pdf);
    $pdf .= "$id 0 obj\n$obj\nendobj\n";
}
$xref = strlen($pdf);
$pdf .= "xref\n0 " . (count($pdfObjects) + 1) . "\n";
$pdf .= "0000000000 65535 f \n";
for ($i = 1; $i <= count($pdfObjects); $i++) {
    $pdf .= sprintf("%010d 00000 n \n", $offsets[$i] ?? 0);
}
$pdf .= "trailer\n<< /Size " . (count($pdfObjects) + 1) . " /Root $catalogId 0 R >>\nstartxref\n$xref\n%%EOF";

$filename = $id !== '' ? 'contact_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $id) . '.pdf' : 'contacts.pdf';
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($pdf));
echo $pdf;
exit;
